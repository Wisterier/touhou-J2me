import java.io.IOException;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

public class GameCanvas extends javax.microedition.lcdui.game.GameCanvas
		implements Runnable, CommandListener {
	/*
	 * @param g Ψһ����
	 * 
	 * @param s ΨһDisplay
	 */
	Graphics g;
	static Display s;
	int dx = Graphics.LEFT | Graphics.TOP;
	Image i, c, r, l;
	Sprite z, right, left;
	int n = 0;

	protected GameCanvas(boolean suppressKeyEvents) {
		super(false);
		s.setCurrent(this);
		g = this.getGraphics();
		try {
			c = Image.createImage("/p00.png");
			r = Image.createImage("/pl00.png");
			l = Image.createImage("/l.png");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		z = new Sprite(c, c.getWidth() / 4, c.getHeight());
		right = new Sprite(r, r.getWidth() / 7, r.getHeight());
		left = new Sprite(l, l.getWidth() / 7, l.getHeight());
		z.setPosition(80, 260);

		this.setFullScreenMode(true);
		this.setCommandListener(this);
		new Thread(this).start();
		// TODO Auto-generated constructor stub
	}

	public void run() {
		try {
			i = Image.createImage("/bg3.jpg");
			for (int a = 0; a < 10000; a += 20) {
				if (a == 320) {
					a = 0;
				}
				printBackground(a);
				printScore();
				move();
				printPlayer(n);
				// System.out.println(a);
				this.flushGraphics();
				Thread.sleep(300);

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void printScore() {
		g.setColor(255, 0, 0);
		g.drawString("Score:", 160, 10, dx);
	}

	public void printBackground(int x) {
		/*
		 * ��ͼ����ʵ��˼· ����һ��a����,ÿ������, ��ͼƬ���Ͻǵ�ԭ��ÿ�������ƶ�a��λ,��ȡͼƬ�ĸ߶ȼ�Сa��λ
		 * ����ͼ�᲻�����Ϲ���,���»��пհ׶�� .��ô���Ǿ�ҪͼƬ��ͷ�����ν� ������ͼƬ���Ͻ�Ϊԭ���ȡͼƬ,���ڻ����ϵ��������a��λ.
		 * �����ж�a�Ƿ����320
		 */
		g.setColor(0, 0, 0);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());

		g.drawRegion(i, 0, x, i.getWidth(), i.getHeight() - x,
				Sprite.TRANS_NONE, 0, 0, dx);
		g.drawRegion(i, 0, 0, i.getWidth(), x, Sprite.TRANS_NONE, 0,
				this.getHeight() - x, dx);
		this.flushGraphics();
	}

	// public void printPlayer(){
	// try {
	// c=Image.createImage("/x.jpg");
	// z=new Sprite(c,c.getWidth()/4,c.getHeight());
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// z.paint(g);
	//
	//
	//
	// }
	public void playerInMoving(int k) {
		if (k == 32) {
			right.setPosition(z.getX(), z.getY());
			int a[] = new int[7];
			for (int i = 0; i < 7; i++) {
				a[i] = 6 - i;
			}
			right.setFrameSequence(a);
			z = right;
		}
	}

	public void move() {
		int i = this.getKeyStates();
		// System.out.println(z.getX());
		if (z.getX() > 0) {
			if (i == 4) {
				z.move(-16, 0);
				this.flushGraphics();
			}
		}
		if (z.getX() < 140) {
			if (i == 32) {
				z.move(16, 0);
				// playerInMoving(32);
				this.flushGraphics();
			}
		}
		if (z.getY() <= 260) {
			if (i == 64) {
				z.move(0, 20);
				// System.out.println(z.getY());
				this.flushGraphics();
			}
		}
		if (z.getY() >= 0) {
			if (i == 2) {
				z.move(0, -20);
				this.flushGraphics();
			}
		}
	}

	public void printPlayer(int s) {
		left.setPosition(z.getX(), z.getY());
		right.setPosition(z.getX(), z.getY());
		switch (s) {
		case 0:
			z.paint(g);
			this.flushGraphics();
			z.nextFrame();

			break;
		case 1:
			right.paint(g);
			this.flushGraphics();
			break;
		case 2:
			left.setFrame(6);
			left.paint(g);
			this.flushGraphics();
			break;
		}
	}

	public void commandAction(Command arg0, Displayable arg1) {
		// TODO Auto-generated method stub

	}

	public void keyPressed(int k) {
		System.out.println(k);
		System.out.println(this.getKeyStates());

	}

	public void keyRepeated(int k) {
		System.out.println("��������");
		int i = this.getKeyStates();
		if (i == GameCanvas.RIGHT_PRESSED | i == -3) {
			n = 1;
			this.flushGraphics();
		}
		if (i == javax.microedition.lcdui.game.GameCanvas.LEFT_PRESSED
				|| i == -4) {
			n = 2;
			this.flushGraphics();
		}
	}

	public void keyReleased(int k) {
		System.out.println("�����ɿ�");
		n = 0;
		this.flushGraphics();
	}
}
