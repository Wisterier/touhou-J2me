
public class Character extends GameObject{

}
