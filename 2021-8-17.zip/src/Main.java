import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.List;
import javax.microedition.midlet.MIDletStateChangeException;


public class  Main extends javax.microedition.midlet.MIDlet {
	/**
	 * 
	 */
	public Main() {
		
		Menu.z=Display.getDisplay(this);
		Menu.m=this;
		GameCanvas.s=Display.getDisplay(this);
		// TODO Auto-generated constructor stub
		
//		System.out.println(2);
	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
		// TODO Auto-generated method stub
//     System.out.println(3);
	}

	protected void pauseApp() {
		// TODO Auto-generated method stub
 
	}

	protected void startApp() throws MIDletStateChangeException {
		// TODO Auto-generated method stub
		new Menu("������ħ��",List.IMPLICIT);
//     System.out.println(1);
	}

}
