import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.midlet.MIDletStateChangeException;

public class Menu extends List implements CommandListener {
	/*
	 * @param Title ����
	 * @param  m ΨһMIDlet
	 * @param  z ΨһDisplay
	 * ���������޸ĵı���Ҫ��static����
	 * 
	 * */
	String[] Title = new String[] { "��ʼ��Ϸ", "����", "�˳�" };
	static Main m;
	static Display z;
	Command ok = new Command("ok", 1, Command.OK);

	public Menu(String title, int listType) {
		super(title, listType);
		z.setCurrent(this);
		System.out.println(z.numAlphaLevels());
//		System.out.println(Title.length);
		// TODO Auto-generated constructor stub
		for (int a = 0; a < Title.length; a++) {
			this.append(Title[a], null);
			System.out.println(Title[a]);
		}
//		this.addCommand(ok);
		this.setCommandListener(this);
	}

	public void commandAction(Command arg0, Displayable arg1) {
		// TODO Auto-generated method stub
		int i = this.getSelectedIndex();
		switch(i){
		case 0:
			new GameCanvas(false);
			break;
		case 1:
			break;
		case 2:
			m.notifyDestroyed();
			break;
		}
	}

}
