
public class Bullet {

}
