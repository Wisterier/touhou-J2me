
public class GameObject {
    int hp;
    boolean isDead;
}
